import React from 'react'

export default () => (
  <div className="text-center mt-5">
    <h1>Page Not Found</h1>
  </div>
)
